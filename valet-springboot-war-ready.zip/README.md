Valet Spring Boot WAR (ready)

How to import and run in Eclipse (Tomcat):
1. Extract this zip.
2. In Eclipse: File -> Import -> Existing Maven Projects -> select extracted folder.
3. Update src/main/resources/application.properties with your MySQL credentials.
4. Create database 'valetdb' in MySQL (see provided schema.sql or use Workbench).
5. Build project: Run As -> Maven build (clean package) or 'mvn clean package'.
6. Deploy generated WAR (target/valet-springboot-war.war) to external Tomcat (drop into webapps or use Manager).
7. Open: http://localhost:8080/valet-springboot-war/

Notes:
- Payment integration is dummy: QR points to /static/images/dummy_qr.png.
- If you prefer running embedded (not recommended for JSP), you can run as Spring Boot app but JSP with embedded Tomcat sometimes requires extra config.

package com.example.valet.service;

import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class PaymentGatewayService {

    public Map<String,Object> createQrisPayment(String orderId, int amount) {
        Map<String,Object> resp = new HashMap<>();
        resp.put("order_id", orderId);
        resp.put("amount", amount);
        resp.put("qris_url", "/valet-springboot-war-ready/static/images/dummy_qr.png");
        resp.put("status", "pending");
        return resp;
    }
}

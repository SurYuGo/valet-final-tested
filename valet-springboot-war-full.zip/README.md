Valet Parking - Spring Boot WAR (JSP) - Full project

How to use:
1. Edit src/main/resources/application.properties and set your MySQL credentials and payment.gateway.server-key.
2. Build WAR:
   mvn clean package
   -> target/valet-springboot-war.war

3. Deploy WAR to external Tomcat (drop into tomcat/webapps or use manager)
4. Open app at: http://localhost:8080/valet-springboot-war/ (context path may vary)

Notes:
- The PaymentGatewayService.createQrisPayment currently returns a fake response for demo. Replace with actual API calls (Midtrans/Xendit).
- Webhook endpoint: POST /api/webhook/gateway
- JSPs are under WEB-INF/jsp
- Uploaded screenshot included at /static/images/spring_xml.png

package com.example.valet.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import java.util.Map;
import java.util.HashMap;

@Service
public class PaymentGatewayService {

    @Value("${payment.gateway.base-url:https://api.sandbox.midtrans.com}")
    private String baseUrl;

    @Value("${payment.gateway.server-key:}")
    private String serverKey;

    private final RestTemplate rest = new RestTemplate();

    /**
     * Placeholder create QRIS payment.
     * For production replace with gateway SDK or proper API request (Midtrans/Xendit).
     */
    public Map<String, Object> createQrisPayment(String orderId, int amount) {
        // Example: build a fake response for sandbox demo.
        Map<String,Object> resp = new HashMap<>();
        resp.put("order_id", orderId);
        resp.put("amount", amount);
        resp.put("qris_url", "https://example.com/qrcode/" + orderId);
        resp.put("status", "pending");
        return resp;
    }
}

package com.example.valet.controller;

import com.example.valet.model.Parking;
import com.example.valet.model.Payment;
import com.example.valet.repository.ParkingRepository;
import com.example.valet.repository.PaymentRepository;
import com.example.valet.service.PaymentGatewayService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.time.Instant;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

@Controller
public class ParkingController {

    @Autowired
    private ParkingRepository parkingRepository;

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private PaymentGatewayService paymentGatewayService;

    @GetMapping({"/","/index"})
    public String index(Model model) {
        model.addAttribute("parkings", parkingRepository.findAll());
        return "index";
    }

    @PostMapping("/api/entry")
    public String entry(@RequestParam(required=false) String plate) {
        String id = UUID.randomUUID().toString();
        Parking p = new Parking();
        p.setId(id);
        p.setPlate(plate == null ? "UNKNOWN" : plate);
        p.setEntryTime(Instant.now());
        parkingRepository.save(p);
        return "redirect:/index";
    }

    @PostMapping("/api/exit/{parkingId}")
    public String exit(@PathVariable String parkingId, Model model) {
        Optional<Parking> opt = parkingRepository.findById(parkingId);
        if (opt.isEmpty()) {
            model.addAttribute("error", "Parking not found");
            return "index";
        }
        Parking p = opt.get();
        p.setExitTime(Instant.now());
        int fee = calculateFee(p.getEntryTime(), p.getExitTime());
        p.setFee(fee);
        String paymentId = "pay-" + UUID.randomUUID().toString();
        p.setPaymentId(paymentId);
        parkingRepository.save(p);

        Payment pay = new Payment();
        pay.setId(paymentId);
        pay.setParkingId(parkingId);
        pay.setAmount(fee);
        pay.setStatus("pending");
        pay.setCreatedAt(Instant.now());
        paymentRepository.save(pay);

        Map<String, Object> gatewayResp = paymentGatewayService.createQrisPayment(paymentId, fee);
        model.addAttribute("payment", gatewayResp);
        model.addAttribute("parking", p);
        return "payment";
    }

    @GetMapping("/api/payment/{paymentId}")
    @ResponseBody
    public ResponseEntity<?> payment(@PathVariable String paymentId) {
        Optional<Payment> p = paymentRepository.findById(paymentId);
        if (p.isEmpty()) return ResponseEntity.notFound().build();
        Payment pay = p.get();
        return ResponseEntity.ok(Map.of(
            "id", pay.getId(),
            "status", pay.getStatus(),
            "amount", pay.getAmount(),
            "raw", pay.getRawResponse()
        ));
    }

    @PostMapping("/api/webhook/gateway")
    @ResponseBody
    public ResponseEntity<?> webhook(@RequestBody Map<String,Object> payload) {
        String orderId = (String) payload.getOrDefault("order_id", payload.get("orderId"));
        String status = (String) payload.getOrDefault("transaction_status", payload.get("status"));
        if (orderId == null) return ResponseEntity.badRequest().build();
        Optional<Payment> op = paymentRepository.findById(orderId);
        if (op.isPresent()) {
            Payment pay = op.get();
            pay.setStatus(status);
            paymentRepository.save(pay);
            if ("settlement".equals(status) || "capture".equals(status) || "success".equals(status)) {
                Optional<Parking> pp = parkingRepository.findById(pay.getParkingId());
                pp.ifPresent(parking -> {
                    parking.setPaid(true);
                    parkingRepository.save(parking);
                });
            }
        }
        return ResponseEntity.ok(Map.of("ok", true));
    }

    private int calculateFee(Instant entry, Instant exit) {
        long seconds = Math.max(0, exit.getEpochSecond() - entry.getEpochSecond());
        long hours = Math.max(1, (seconds + 3599) / 3600);
        return (int)(hours * 5000);
    }
}
